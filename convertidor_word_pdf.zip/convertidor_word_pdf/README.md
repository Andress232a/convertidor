# Convertidor de Word a PDF 📄➡️📑

## Descripción
Una aplicación web simple y profesional para convertir archivos de Microsoft Word (.docx, .doc) a PDF.

## Características
- Interfaz de usuario moderna y limpia
- Conversión rápida y sencilla
- Soporte para archivos .docx y .doc
- Límite de tamaño de archivo de 16MB

## Requisitos
- Python 3.7+
- Flask
- pdf2docx

## Instalación
1. Clonar el repositorio
2. Crear un entorno virtual (opcional pero recomendado)
3. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```

## Uso
Ejecutar la aplicación:
```
python app.py
```
Abrir un navegador en `http://localhost:5000`

## Tecnologías
- Backend: Flask (Python)
- Frontend: HTML5, JavaScript, Bootstrap
- Conversión: pdf2docx
