from flask import Flask, render_template, request, send_file
from pdf2docx import Converter
import os
import uuid

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Límite de 16MB

# Asegurarse de que la carpeta de uploads exista
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    if 'file' not in request.files:
        return 'No se ha seleccionado ningún archivo', 400
    
    file = request.files['file']
    
    if file.filename == '':
        return 'Archivo no válido', 400
    
    if not file.filename.lower().endswith(('.docx', '.doc')):
        return 'Solo se permiten archivos de Word (.docx, .doc)', 400
    
    # Generar nombre de archivo único
    input_filename = os.path.join(app.config['UPLOAD_FOLDER'], f"{uuid.uuid4()}_{file.filename}")
    output_filename = input_filename.replace('.docx', '.pdf').replace('.doc', '.pdf')
    
    # Guardar archivo de entrada
    file.save(input_filename)
    
    try:
        # Convertir de Word a PDF
        cv = Converter(input_filename)
        cv.convert(output_filename)
        cv.close()
        
        # Eliminar archivo de entrada temporal
        os.remove(input_filename)
        
        # Enviar archivo PDF
        return send_file(output_filename, as_attachment=True, download_name=os.path.basename(output_filename))
    
    except Exception as e:
        # Limpiar archivos en caso de error
        if os.path.exists(input_filename):
            os.remove(input_filename)
        if os.path.exists(output_filename):
            os.remove(output_filename)
        
        return f'Error en la conversión: {str(e)}', 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
